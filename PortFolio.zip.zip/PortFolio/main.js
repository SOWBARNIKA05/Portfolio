const clickMe = document.getElementById('click-me');
const second = document.getElementById('second');

clickMe.addEventListener('click', () => {
  home.scrollIntoView({ behavior: 'smooth' });
});